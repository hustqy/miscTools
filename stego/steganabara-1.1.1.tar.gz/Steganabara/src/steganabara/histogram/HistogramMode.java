package steganabara.histogram;

public enum HistogramMode {

	GRAYSCALE, RED, GREEN, BLUE;

}
